package com.lezhin.coding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LezhinCodingApplication {

    public static void main(String[] args) {
        SpringApplication.run(LezhinCodingApplication.class, args);
    }

}
